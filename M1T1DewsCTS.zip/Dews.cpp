// CTS 285
// M1T1
// Clarence Dews
// 22 August 2021
#include <iostream>
using namespace std;
int main() {
  cout << "My name is Clarence Dews\n";
  cout << "I am currently studying C++ and C# this semester.\n";
  cout<< "My hobbies include playing golf, going to the gym, and playing a card game named Magic The Gathering.\n";
  cout<< "I am currently working a full time job at a plumbing warehouse as well."<<endl;
}